/* public/firebase-messaging-sw.js */
importScripts("https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyBxfQXbnfPWGwtlgxuLf6Sas6rB9JOGWYU",
  authDomain: "health-tracker-21d43.firebaseapp.com",
  projectId: "health-tracker-21d43",
  storageBucket: "health-tracker-21d43.appspot.com",
  messagingSenderId: "1086755747536",
  appId: "1:1086755747536:web:b678dbe82a504302c850d5"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log("🔕 Background Message:", payload);
  self.registration.showNotification(payload.notification.title, {
    body: payload.notification.body,
  });
});
