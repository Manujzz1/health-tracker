// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getMessaging, getToken, onMessage } from "firebase/messaging";

const firebaseConfig = {
  apiKey: "AIzaSyBxfQXbnfPWGwtlgxuLf6Sas6rB9JOGWYU",
  authDomain: "health-tracker-21d43.firebaseapp.com",
  projectId: "health-tracker-21d43",
  storageBucket: "health-tracker-21d43.appspot.com",
  messagingSenderId: "1086755747536",
  appId: "1:1086755747536:web:b678dbe82a504302c850d5"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);

// 🔔 FCM Setup
export const messaging = getMessaging(app);
export const requestNotificationPermission = async () => {
  const permission = await Notification.requestPermission();
  if (permission === "granted") {
    const token = await getToken(messaging, {
      vapidKey: "BJe4Ia1nzOqBl2yQCrXReTbm5yuLjYitGpZMi_fa-VyI213ru0GgczFh-vo3CE32ePaCrDtv6tNQRo6xjfXaLIc",
    });
    console.log("FCM Token:", token);
    // Optional: Save to Firestore for server use
  } else {
    console.warn("Notification permission denied");
  }
};

onMessage(messaging, (payload) => {
  console.log("🔔 Foreground message received:", payload);
  if (Notification.permission === "granted") {
    new Notification(payload.notification.title, {
      body: payload.notification.body,
    });
  }
});
